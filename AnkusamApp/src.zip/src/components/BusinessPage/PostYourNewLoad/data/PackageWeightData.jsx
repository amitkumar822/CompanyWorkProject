const packageweightdata = [
    "Below 1 Ton",
    "1 Ton",
    "2 Ton",
    "3 Ton",
    "4 Ton",
    "5 Ton",
    "6 Ton",
    "7 Ton",
    "8 Ton",
    "9 Ton",
    "10-15 Ton",
    "15-20 Ton",
    "20-25 Ton",
    "25-30 Ton",
    "30-35 Ton",
    "35-40 Ton",
    "40-45 Ton",
    "45-50 Ton",
    "Aboves 50 Ton",
]

export { packageweightdata }